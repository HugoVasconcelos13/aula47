var nave1,nave2;
var obstacle1,obstacle2;
var fuel,life,explosion;
var star,stars;
var nave1Img,obstacle1Img,obstacle2Img;
var starImg,fuelImg,explosionImg;
var backgroundImg;
var edges;
var obstacles;
var life = 10;

function preload() {
nave1Img = loadImage("imagens/nave.png");
obstacle1Img = loadImage("imagens/meteoro.png");
obstacle2Img = loadImage("imagens/satelite.png");
starImg = loadImage("imagens/estrela.png");
fuelImg = loadImage("imagens/gasolina.png");
backgroundImg = loadImage("imagens/background.gif");
explosionImg = loadImage("imagens/explosao.png");
}

function setup() {
  createCanvas(windowWidth,windowHeight);

  edges = createEdgeSprites();
  
  obstacles = new Group();
  stars = new Group();
   
  nave1 = createSprite(650,580,20,20);
  nave1.addImage("nave1",nave1Img)
  nave1.scale = 0.17;
}

function draw() {
 background("red");
 image(backgroundImg,0,0,width,height);
 drawSprites();
console.log("pos x "+nave1.x+"pos y "+nave1.y);

if(keyIsDown(UP_ARROW)){
    nave1.position.y -=5;
}

if(keyIsDown(RIGHT_ARROW)){
    nave1.position.x +=5;

}if(keyIsDown(LEFT_ARROW)){
    nave1.position.x -=5;
}
if(keyIsDown(DOWN_ARROW)){
    nave1.position.y +=5;
}



text("vidas: "+life,30,30);

spawnObstacles();
removeLife();
spawnStars();
collectStars();

nave1.bounceOff(edges);

 
}
function spawnObstacles() {
 //criar o srpite dos obstáculos
 if (frameCount%50==0){

 obstacle1 = createSprite(Math.round(random(40,1280)),Math.round(random(43,580)));
 var num = Math.round(random(1,2));
 switch(num){
     case 1:obstacle1.addImage("obstacle1",obstacle1Img);
     break;
     case 2:obstacle1.addImage("obstacle2",obstacle2Img);
     break;
     default:break;
 }
 obstacle1.scale = 0.15;
 obstacle1.velocityY = 3;
 obstacle1.lifetime = 550;

 obstacles.add(obstacle1);
 
 }

}
function spawnStars(){
 if (frameCount %50==0){
     star = createSprite(Math.round(random(40,1280)),Math.round(random(43,580)));
     star.addImage(starImg);

    stars.add(star);

     star.scale = 0.14;
     star.velocityY = 3;
     star.lifeTime = 550;
 }
}


function collectStars(){
    nave1.overlap(stars,function(collector,collected){
    life+=1;
    collected.remove();
    })
}

function removeLife(){
    nave1.overlap(obstacles,function(collector,collected){
    life-=1;
        collected.remove();
    })
}